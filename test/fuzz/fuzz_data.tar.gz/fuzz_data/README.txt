make_fuzz_data.py -- runtime files and seed corpora for the samtools fuzzers
(view, consensus, calmd, fixmate, markdup, sort, flagstat, stats,
depth, mpileup, fastq, index, coverage, bedcov, regions, merge, cat,
collate, split, addreplacerg, reheader, ampliconclip, ampliconstats,
dict, import, reference, reset, depad, phase, targetcut, cram_size,
samples, checksum, head, quickcheck, rmdup, tview, faidx and faidx_idx).

Usage: ./make_fuzz_data.py [OUTDIR]          (default: fuzz_data)

Pure Python 3 with no dependencies, and deterministic.  If samtools is on
PATH, BAM and CRAM (no_ref) copies of the SAM seeds are produced as well.

Output:
  OUTDIR/runtime/        copy into the fuzzer's working directory
  OUTDIR/sam/, fasta/    the seed payloads without control bytes, to read
  OUTDIR/seeds/<fuzzer>/ initial corpora, control bytes prepended
